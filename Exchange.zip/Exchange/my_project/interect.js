const Web3 = require("web3");
const ethers = require("ethers");

const provider = new Web3.providers.HttpProvider(`https://vm-216.s3it.uzh.ch`);
const web3 = new Web3(provider);


const BetcontractABI = require("./betcontractabi.json");
const BetcontractAddress = "0x5B012ad3346BABa2b69b364041fc6A9741bD54a3";
const Betcontract = new web3.eth.Contract(BetcontractABI, BetcontractAddress);

const contractABI = require("./contractabi.json");
const contractAddress = "0xa1FC229a8665090FC458F4D13C55eB8Af5E3164E";
const contract = new web3.eth.Contract(contractABI, contractAddress);



//----------------------------------------------

async function Approve(spender,amount,myAddress,privateKey) {
    const functionName = "approve";
    const functionArgs = [spender,amount];
    const functionABI = Betcontract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: BetcontractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privateKey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);
    console.log("Approve Transaction result:", result);
}

async function Mint(myAddress,privatekey,mint_amount) {
    const functionName = "mint";
    const functionArgs = [myAddress,mint_amount];
    const functionABI = Betcontract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: BetcontractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privatekey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);

    console.log("Mint Transaction result:", result);
}

async function Register(myAddress,privateKey) {
    const functionName = "register";
    const functionArgs = [];
    const functionABI = contract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: contractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privateKey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);
    console.log("Register Transaction result:", result);
}

async function balanceRefresh(myAddress,privateKey) {
    const functionName = "balanceRefresh";
    const functionArgs = [];
    const functionABI = contract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: contractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privateKey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);

    console.log("balanceRefresh Transaction result:", result);
}

async function placeBet(number, betAmount,myAddress,privateKey) {
    const functionName = "placeBet";
    const functionArgs = [number, betAmount];
    const functionABI = contract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: contractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privateKey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);

    console.log(" placeBet Transaction result:", result);
}

async function pickWinner(myAddress,privateKey) {
    const functionName = "pickWinner";
    const functionArgs = [];
    const functionABI = contract.methods[functionName](...functionArgs).encodeABI();
    const nonce = await web3.eth.getTransactionCount(myAddress);
    const tx = {
        from: myAddress,
        to: contractAddress,
        data: functionABI,
        gas: 1000000,
        nonce: nonce,
    };
    const signedTransaction = await web3.eth.accounts.signTransaction(tx, privateKey);
    const result = await web3.eth.sendSignedTransaction(signedTransaction.rawTransaction);

    console.log("pickWinner Transaction result:", result);
}

async function getWinnerIndex() {
    try {
        const result = await contract.methods.getWinnerIndex().call();
        console.log("WinnerIndex:", result);
        return result;
    } catch (error) {
        console.error("Error in getNumber:", error);
    }
}
async function getUsrBalance(address) {
    try {
        const result = await contract.methods.getUsrBalance(address).call();
        console.log("UsrBalance:", result);
        return result;
    } catch (error) {
        console.error("Error in getNumber:", error);
    }
}
async function getUsrStake(address) {
    try {
        const result = await contract.methods.getUsrBalance(address).call();
        console.log("UsrStake:", result);
        return result;
    } catch (error) {
        console.error("Error in getNumber:", error);
    }
}
async function getUsrBetNumber(address) {
    try {
        const result = await contract.methods.getUsrBalance(address).call();
        console.log("UsrBetNumber:", result);
        return result;
    } catch (error) {
        console.error("Error in getNumber:", error);
    }
}

//----------------------------------------------
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

app.post('/login', async (req, res) => {
    try {
    const myAddress = req.query.username;
    const privateKey = req.query.password;
    const bell2 =await balanceRefresh(myAddress,privateKey)
    const bell3 =    await getUsrBalance(myAddress)
    const bell4 =await Approve(contractAddress,100000,myAddress,privateKey)
    console.log("Transaction result:", bell3);
    const token = {address: myAddress,privatekey:privateKey,money:bell3};
    res.json(token);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred' });
    }
});

app.post('/regist', async (req, res) => {
    try {
        const myAddress = req.query.username;
        const privateKey = req.query.password;
        //--------------
        const bell1=    await Register(myAddress,privateKey);
        const bell2 =await balanceRefresh(myAddress,privateKey)
        const bell3 =    await getUsrBalance(myAddress)
        const bell4 =await Approve(contractAddress,100000,myAddress,privateKey)
        console.log("Transaction result:", bell3);
//--------------
        const token = {address: myAddress,privatekey:privateKey,money:bell3};
        res.json(token);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred' });
    }
});

app.post('/addmoney', async (req, res) => {
    try {
    const balance = req.query.balance;
    const walletAddress = req.query.walletAddress;
    const privatekey = req.query.privatekey;
    await Mint(walletAddress,privatekey,500)
    const bell2 =await balanceRefresh(walletAddress,privatekey)
    const bell3 =    await getUsrBalance(walletAddress)
    const token = {address: walletAddress, privatekey: privatekey, money: bell3};
    res.json(token);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred' });
    }
});

app.post('/bet', async (req, res) => {
    try {
    let betMap = req.query.value;
    let playerAmount = req.query.playerAmount;
    let myAddress = req.query.myAddress;
    let privateKey = req.query.privateKey;
    const bell4 =await Approve(contractAddress,100000,myAddress,privateKey)
    await placeBet(parseInt(betMap), parseInt(playerAmount),myAddress,privateKey)
    console.log(betMap+playerAmount)
    await pickWinner(myAddress,privateKey)
    const bell2 =await balanceRefresh(myAddress,privateKey)
    // console.log(bell2)
    const playerAmount1 =    await getUsrBalance(myAddress)
    console.log(playerAmount1)
    let difference = playerAmount1 - playerAmount;
    const number =await getWinnerIndex()
    let winMessages = [];
    winMessages.push(`You now money: ${playerAmount1}`);
    //----------------------------
    const token = {playerAmount: playerAmount1, lastSpin: number, lastResult: difference, lastWinMessages: winMessages};
    res.json(token);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'An error occurred' });
    }
});


// 启动服务器
app.listen(8000, () => {
    console.log('Node.js server running on port 8000');
});

