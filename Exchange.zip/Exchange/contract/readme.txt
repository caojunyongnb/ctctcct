1.connect to uzheth test network by metamask
Network name: UZHETH
RCL URL :https://vm-216.s3it.uzh.ch
Chain ID :702
Currency sign: UZHETH
2.Deploy:
2.1 Deploy Dai.sol and get the contract address
2.2 Deploy Lottery, copy dai contract into address_token and deploy.

Function:
Register(): call this function to store participants's information into  contract
BalanceRefresh(): refresh all participants' balance
PlaceBet(): Select a number and decide the amount you'd like to wager.
pickWinner(): Give the player the money they've won, and refresh the winner information for the next slot
